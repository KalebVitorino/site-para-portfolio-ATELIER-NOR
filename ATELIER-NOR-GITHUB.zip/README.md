# ATELIER NØR

Landing page/portfolio editorial para um estúdio fictício de arquitetura e interiores.

## Deploy no Netlify

### Opção 1 — arrastar e soltar
1. Acesse o Netlify.
2. Abra **Add new site > Deploy manually**.
3. Arraste a pasta `atelier-nor` (ou o conteúdo dela) para a área de deploy.
4. O site não precisa de build.

### Opção 2 — Git
- Build command: deixe vazio.
- Publish directory: `.`

## Estrutura
- `index.html`: HTML, CSS e JavaScript em um único arquivo.
- `netlify.toml`: configuração de publicação e headers de segurança.

## Observação
As imagens são carregadas do Unsplash. Se quiser uma versão 100% autônoma, baixe as imagens e troque as URLs no `index.html` por caminhos locais.
